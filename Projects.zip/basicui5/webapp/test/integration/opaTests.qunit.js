/* global QUnit */

sap.ui.require(["com/rebit/fico/basicui5/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
