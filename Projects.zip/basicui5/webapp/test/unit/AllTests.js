sap.ui.define([
	"com/rebit/fico/basicui5/test/unit/controller/S1.controller"
], function () {
	"use strict";
});
