sap.ui.define([
	"com/rebit/jsonmodelexample/test/unit/controller/S1.controller"
], function () {
	"use strict";
});
